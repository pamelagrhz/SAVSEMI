﻿using System;
using System.Web;
using System.Web.UI;

namespace SAVSEM
{
	public partial class RegistroExitoso : System.Web.UI.Page
	{
	}
}

