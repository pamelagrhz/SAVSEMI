﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SAVSEM
{
	public partial class Buscar : System.Web.UI.Page
	{
		protected void Page_Load(Object sender, EventArgs e){
			((TextBox)Master.FindControl("txtBuscar")).Text = Session ["busqueda"].ToString ();
		}
	}
}

